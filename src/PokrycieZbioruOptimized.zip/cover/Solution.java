package cover;
import java.util.ArrayList;

public abstract class Solution
{
    public abstract ArrayList<Integer> solve(FiniteSet target, SetFamily family);
}
