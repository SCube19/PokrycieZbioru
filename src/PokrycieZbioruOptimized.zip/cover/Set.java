package cover;

public abstract class Set
{
    public abstract boolean checkForExistence(int element);
}
